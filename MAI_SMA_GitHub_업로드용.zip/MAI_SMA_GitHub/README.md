# MAI SMA · Smart Maintenance Advisor

선박 정비 기록을 대상으로 집계형 Text-to-SQL 질의와 절차형 BM25 검색·인용 응답을 제공하는 로컬 웹 챗봇입니다. 모델 API와 웹 서버는 기본적으로 이 PC에서만 사용합니다.

## 필요한 파일

이 저장소에는 실행 코드와 프롬프트만 포함합니다. 데이터와 개인 설정은 저장소에 올리지 않습니다.

로컬 실행 전에 `data/` 폴더에 아래 파일을 준비하세요.

- `MAI_SMA_학생용DB_1000.duckdb` — 사용자에게 제공된 DB 파일
- `datadict_deid.txt` — DB 컬럼 설명 파일
- `demo_questions.txt` — 선택 사항, 시작 화면의 질문 예시

검색 색인 `bm25_1000.pkl`이 없으면 서버가 DB에서 다시 만듭니다. `.gitignore`가 DB·색인·질문 파일을 Git에서 제외합니다.

## 로컬 실행

1. Python 3.10 이상과 Ollama를 설치합니다.
2. Ollama에서 사용할 모델을 준비합니다. 기본 설정은 `llama3.1:8b`입니다.
3. 이 저장소에서 `config.example.json`을 `config.json`으로 복사하고 모델 이름과 DB 파일 경로를 확인합니다.
4. `START.bat`을 실행합니다. DuckDB가 없으면 설치 안내가 표시됩니다.
5. 설정한 포트로 브라우저에서 접속합니다. 기본 포트는 `8760`입니다.
6. 종료할 때는 `STOP.bat`을 실행합니다.

필수 Python 패키지는 `requirements.txt`에 있습니다. 기본 실행은 Ollama OpenAI 호환 주소 `http://localhost:11434/v1`을 사용합니다.

## 구성

| 경로 | 역할 |
|---|---|
| `app/maintqa_web.py` | HTTP 서버, 질문 경로, DB·검색 처리와 출처 응답 |
| `app/maintqa_web.html` | 브라우저 인터페이스 |
| `app/router.py` | SQL 집계형과 절차형 검색의 규칙 라우터 |
| `app/harness.py` | DuckDB 읽기 전용 연결, SQL 실행 통제 |
| `app/rag.py` | BM25 검색 색인과 기록 검색 |
| `app/llm_client.py` | Ollama 등 OpenAI 호환 모델 연결 |
| `app/answer_text.py` | 집계 결과 답변 문장 구성 |
| `prompts/` | SQL 생성·검색·번역 지침 |
| `tools/` | 연결 점검과 검색 색인 관리 도구 |
| `config_examples/` | 실행기별 설정 예시 |

세부 흐름은 `docs/아키텍처_설명.md`를 참고하세요.

## GitHub에 올릴 때

저장소 루트에서 `git init` 후 확인하고 커밋합니다. `.gitignore`에 DB, 검색 색인, 로컬 `config.json`, 로그가 포함되어 있습니다. 실제로 push하기 전에 `git status`에서 데이터 파일이나 비밀 키가 추적 대상으로 보이지 않는지 확인하세요.

라이선스는 프로젝트 소유자가 선택할 수 있도록 임의로 추가하지 않았습니다.
