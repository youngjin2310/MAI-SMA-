# Local data files

Copy the database and data dictionary supplied to you into this folder. These files are intentionally excluded from Git by the repository `.gitignore`.

Required:

- `MAI_SMA_학생용DB_1000.duckdb`
- `datadict_deid.txt`

Optional:

- `demo_questions.txt`
- `bm25_1000.pkl` (if absent, the app rebuilds the index from the database)
