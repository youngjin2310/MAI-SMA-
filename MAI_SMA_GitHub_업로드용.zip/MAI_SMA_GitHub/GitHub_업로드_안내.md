# GitHub 업로드 순서

## GitHub Desktop 사용

1. GitHub Desktop을 열고 **File → Add Local Repository**를 선택합니다.
2. 이 폴더를 지정합니다: `논문 자료/MAI_SMA_GitHub`.
3. 로컬 저장소가 아니라고 안내되면 **Create a repository**를 선택합니다.
4. 변경 파일 목록을 확인합니다. `.gitignore`가 DB, 검색 색인, 로컬 설정을 제외하는지 살펴봅니다.
5. Summary에 커밋 메시지를 입력하고 **Commit to main**을 선택합니다.
6. **Publish repository**를 눌러 GitHub에 올립니다. 비공개 저장소로 시작하면 공개 범위를 검토한 뒤 바꿀 수 있습니다.

## Git 명령 사용

저장소 폴더에서 아래 명령을 실행합니다.

```powershell
git init
git add .
git status
git commit -m "Prepare MAI SMA source"
```

`git status`에서 `config.json`, `.duckdb`, `.pkl`, `datadict_deid.txt`, `demo_questions.txt`가 보이면 커밋하지 말고 `.gitignore`를 먼저 확인합니다. 그다음 GitHub에서 빈 저장소를 만들고 안내된 `git remote add origin ...` 및 `git push -u origin main` 명령으로 업로드합니다.
